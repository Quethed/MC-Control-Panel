package com.quethed.control_panel;
import javax.annotation.Nullable;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
public class TileEntityMotherboard extends TileEntity{
	protected BlockPos link;
	@Override public ITextComponent getDisplayName(){return getMasterTE().getDisplayName();}
	public BlockPos getLink(){return link==null?null:ControlPanel.rotate(pos.up(link.getY()),link.getX(),link.getZ(),ControlPanel.getRotation(world.getBlockState(pos).getValue(BlockHorizontal.FACING)));}
	public int getMasterDistance(){return Math.max(Math.abs(link.getX()),Math.max(Math.abs(link.getY()),Math.abs(link.getZ())));}
	public TileEntity getMasterTE(){return link==null?null:world.getTileEntity(getLink());}
	@Override public NBTTagCompound getUpdateTag(){return writeToNBT(new NBTTagCompound());}
	@Override public void onDataPacket(NetworkManager net,SPacketUpdateTileEntity pkt){readFromNBT(pkt.getNbtCompound());}
	@Override public void readFromNBT(NBTTagCompound compound){
		super.readFromNBT(compound);
		if(compound.hasKey("LinkX",3)&&compound.hasKey("LinkY",3)&&compound.hasKey("LinkZ",3)){
			link=new BlockPos(compound.getInteger("LinkX"),compound.getInteger("LinkY"),compound.getInteger("LinkZ"));
			setLink(null,true);
		}
		if(compound.hasKey("RelativeLinkX",3)&&compound.hasKey("RelativeLinkY",3)&&compound.hasKey("RelativeLinkZ",3)){
			link=new BlockPos(compound.getInteger("RelativeLinkX"),compound.getInteger("RelativeLinkY"),compound.getInteger("RelativeLinkZ"));
		}
		if(world==null)return;
		IBlockState s=world.getBlockState(getPos());
		world.notifyBlockUpdate(getPos(),s,s,2);
	}
	public void setLink(@Nullable EntityLivingBase placer,boolean set){
		if(link==null||(!set&&(placer==null||placer.getEntityWorld().isRemote)))return;
		TileEntity t=world.getTileEntity(set?link:getLink());
		if(t instanceof TileEntityControlPanel){
			if(set){
				link=new BlockPos(link.getX()-pos.getX(),link.getY()-pos.getY(),link.getZ()-pos.getZ());
				((TileEntityControlPanel)t).addLink(link);
				IBlockState s=world.getBlockState(link);
				world.notifyBlockUpdate(link,s,s,2);
			}
			else if(placer instanceof EntityPlayer){
				int c=((TileEntityControlPanel)t).getLinkCount();
				if(c>2)((EntityPlayer)placer).sendStatusMessage(new TextComponentTranslation("tile.motherboard.manyLinks",c).setStyle(new Style().setColor(TextFormatting.GOLD).setBold(true).setUnderlined(true)),true);
			}
		}
	}
	@Override public NBTTagCompound writeToNBT(NBTTagCompound compound){
		compound=super.writeToNBT(compound);
		if(link==null)return super.writeToNBT(compound);
		compound.setInteger("RelativeLinkX",link.getX());
		compound.setInteger("RelativeLinkY",link.getY());
		compound.setInteger("RelativeLinkZ",link.getZ());
		return compound;
	}
}