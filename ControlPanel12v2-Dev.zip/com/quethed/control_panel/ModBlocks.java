package com.quethed.control_panel;
import com.quethed.control_panel.blocks.BlockControl;
import com.quethed.control_panel.blocks.BlockControlPanel;
import com.quethed.control_panel.blocks.BlockControlPanelTouchscreen;
import com.quethed.control_panel.blocks.BlockControlTouchscreen;
import com.quethed.control_panel.blocks.BlockGauge;
import com.quethed.control_panel.blocks.BlockGaugeComparator;
import com.quethed.control_panel.blocks.BlockMotherboard;
import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
public class ModBlocks{
	@GameRegistry.ObjectHolder("controlpanel:control_block")public static final BlockControl CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:control_panel")public static final BlockControlPanel CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_control_block")public static final BlockControl DARK_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_control_panel")public static final BlockControlPanel DARK_CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_touchscreen_control_block")public static final BlockControlTouchscreen DARK_TOUCHSCREEN_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_touchscreen_control_panel")public static final BlockControlPanelTouchscreen DARK_TOUCHSCREEN_CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:motherboard")public static final BlockMotherboard MOTHERBOARD=null;
	@GameRegistry.ObjectHolder("controlpanel:powered_gauge_comparator")public static final BlockGaugeComparator POWERED_GAUGE_COMPARATOR=null;
	@GameRegistry.ObjectHolder("controlpanel:redstone_gauge")public static final BlockGauge REDSTONE_GAUGE=null;
	@GameRegistry.ObjectHolder("controlpanel:touchscreen_control_block")public static final BlockControlTouchscreen TOUCHSCREEN_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:touchscreen_control_panel")public static final BlockControlPanelTouchscreen TOUCHSCREEN_CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:unpowered_gauge_comparator")public static final BlockGaugeComparator UNPOWERED_GAUGE_COMPARATOR=null;
	static void init()throws Exception{
		CONTROL_BLOCK.setHarvestLevel("pickaxe",0);
		CONTROL_PANEL.setHarvestLevel("pickaxe",0);
		DARK_CONTROL_BLOCK.setHarvestLevel("pickaxe",0);
		DARK_CONTROL_PANEL.setHarvestLevel("pickaxe",0);
		DARK_TOUCHSCREEN_CONTROL_BLOCK.setHarvestLevel("pickaxe",0);
		DARK_TOUCHSCREEN_CONTROL_PANEL.setHarvestLevel("pickaxe",0);
		MOTHERBOARD.setHarvestLevel("pickaxe",0);
		REDSTONE_GAUGE.setHarvestLevel("pickaxe",0);
		TOUCHSCREEN_CONTROL_BLOCK.setHarvestLevel("pickaxe",0);
		TOUCHSCREEN_CONTROL_PANEL.setHarvestLevel("pickaxe",0);
		ItemBlockLinkable a=ModItems.MOTHERBOARD;
		a.link.add(CONTROL_BLOCK);
		a.link.add(CONTROL_PANEL);
		a.link.add(DARK_CONTROL_BLOCK);
		a.link.add(DARK_CONTROL_PANEL);
		a.link.add(DARK_TOUCHSCREEN_CONTROL_BLOCK);
		a.link.add(DARK_TOUCHSCREEN_CONTROL_PANEL);
		a.link.add(TOUCHSCREEN_CONTROL_BLOCK);
		a.link.add(TOUCHSCREEN_CONTROL_PANEL);
		a=ModItems.REDSTONE_GAUGE;
		a.link.add(Blocks.UNPOWERED_COMPARATOR);
		a.link.add(Blocks.POWERED_COMPARATOR);
		BlockControl.DROPS_WITH_DATA=ControlPanel.CONFIG.getBoolean("drop_controls_with_data","main",false,"Do control panels and control blocks keep their attachments when broken? When false, they drop the attachments seperately instead.");
		String[]e=ControlPanel.CONFIG.getStringList("extraction_items","main",new String[]{
			"buildcraftcore:wrench",
			"ic2:wrench",
			"ic2:wrench_new",
			"ic2:electric_wrench",
			"lasermod:wrench",
			";",
			"cfm:item_hammer",
			"minecraft:shears"
		},"The list of items to use when extracting buttons or levers from control panels. ';' marks the beginning of backups and only the first backup can count. Backup entries only count when no other registry works. You should not have a need for backups.");
		boolean b=false;
		for(String s:e){
			if(s.trim().matches(";")){
				if(b)throw new Exception("Backup entries have already started.");
				else b=true;
			}
			else if(b){
				if(BlockControl.EXTRACT.size()<1){
					Item i=Item.getByNameOrId(s);
					if(i!=null)BlockControl.EXTRACT.add(i);
				}
			}
			else{
				Item i=Item.getByNameOrId(s);
				if(i!=null)BlockControl.EXTRACT.add(i);
			}
		}
		Item i=Item.getByNameOrId(ControlPanel.CONFIG.getString("button_to_item","main","minecraft:stone_button","what item is counted as the button for control panels."));
		if(i!=null)BlockControl.BUTTON=i;
		i=Item.getByNameOrId(ControlPanel.CONFIG.getString("lever_to_item","main","minecraft:lever","what item is counted as the lever for control panels."));
		if(i!=null)BlockControl.LEVER=i;
	}
	@SubscribeEvent void registerBlocks(RegistryEvent.Register<Block>event){
		event.getRegistry().registerAll(
			new BlockControl().setRegistryName("control_block").setUnlocalizedName("control").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControlPanel().setRegistryName("control_panel").setUnlocalizedName("controlPanel").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControl().setRegistryName("dark_control_block").setUnlocalizedName("controlDark").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControlPanel().setRegistryName("dark_control_panel").setUnlocalizedName("controlPanelDark").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControlTouchscreen().setRegistryName("dark_touchscreen_control_block").setUnlocalizedName("controlTouchscreenDark").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControlPanelTouchscreen().setRegistryName("dark_touchscreen_control_panel").setUnlocalizedName("controlPanelTouchscreenDark").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockMotherboard().setRegistryName("motherboard").setUnlocalizedName("motherboard").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockGaugeComparator(true).setRegistryName("powered_gauge_comparator").setLightLevel(.625f).setUnlocalizedName("comparator"),
			new BlockGauge().setRegistryName("redstone_gauge").setUnlocalizedName("redstoneGauge").setHardness(.75f).setResistance(0).setCreativeTab(CreativeTabs.REDSTONE),
			new BlockControlTouchscreen().setRegistryName("touchscreen_control_block").setUnlocalizedName("controlTouchscreen").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockControlPanelTouchscreen().setRegistryName("touchscreen_control_panel").setUnlocalizedName("controlPanelTouchscreen").setCreativeTab(CreativeTabs.REDSTONE).setHardness(2).setResistance(10),
			new BlockGaugeComparator(false).setRegistryName("unpowered_gauge_comparator").setUnlocalizedName("comparator"));
		BlockMotherboard.distanceLoss=ControlPanel.CONFIG.getFloat("motherboard_distance_power_loss","main",.25f,0,Float.MAX_VALUE,"The redstone strength will lose x every block.");
	}
}