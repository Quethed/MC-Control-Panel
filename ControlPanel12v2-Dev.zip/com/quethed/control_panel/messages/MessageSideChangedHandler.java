package com.quethed.control_panel.messages;
import com.quethed.control_panel.TileEntityControlPanel;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;
public class MessageSideChangedHandler implements IMessageHandler<MessageSideChanged,IMessage>{
	@Override public IMessage onMessage(MessageSideChanged message,MessageContext ctx){
		net.minecraft.client.Minecraft m=net.minecraft.client.Minecraft.getMinecraft();
		m.addScheduledTask(()->{
			BlockPos p=new BlockPos(message.x,message.y,message.z);
			if(!m.world.isBlockLoaded(p))return;
			TileEntity t=m.world.getTileEntity(p);
			if(t instanceof TileEntityControlPanel){
				((TileEntityControlPanel)t).messageRecieved(message.change,message.name);
				if(message.change<18&&m.currentScreen instanceof com.quethed.control_panel.client.GuiControlPanel&&((com.quethed.control_panel.client.GuiControlPanel)m.currentScreen).te==t)
					m.currentScreen.initGui();
			}
		});
		return null;
	}
}