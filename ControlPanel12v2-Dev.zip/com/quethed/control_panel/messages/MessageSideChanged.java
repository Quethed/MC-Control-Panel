package com.quethed.control_panel.messages;
import javax.annotation.Nullable;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.ByteBufUtils;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
public class MessageSideChanged implements IMessage{
	byte change;
	String name;
	int x,y,z;
	public MessageSideChanged(int x,int y,int z,byte change,@Nullable String name){
		this.x=x;
		this.y=y;
		this.z=z;
		this.change=change;
		this.name=name;
	}
	public MessageSideChanged(){}
	@Override public void fromBytes(ByteBuf buf){
		x=buf.readInt();
		y=buf.readInt();
		z=buf.readInt();
		change=buf.readByte();
		if(buf.isReadable())name=ByteBufUtils.readUTF8String(buf);
	}
	@Override public void toBytes(ByteBuf buf){
		buf.writeInt(x);
		buf.writeInt(y);
		buf.writeInt(z);
		buf.writeByte(change);
		if(name!=null)ByteBufUtils.writeUTF8String(buf,name);
	}
}