package com.quethed.control_panel;
import java.util.ArrayList;
import net.minecraft.block.Block;
import net.minecraft.block.ITileEntityProvider;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class ItemBlockLinkable extends ItemBlock{
	public final ArrayList<ITileEntityProvider>link=new ArrayList<ITileEntityProvider>();
	public ItemBlockLinkable(Block block){super(block);}
	@Override@SideOnly(Side.CLIENT)public void addInformation(ItemStack stack,World world,java.util.List<String>tooltip,net.minecraft.client.util.ITooltipFlag flagIn){
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown()){
			String l=net.minecraft.util.text.translation.I18n.translateToLocal(getUnlocalizedName()+".desc");
			String[]s=l.split("\\\\n");
			int i=1;
			for(String t:s){
				tooltip.add(i,t);
				i++;
			}
		}
		else tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocal("moreInfo"));
		NBTTagCompound a=stack.getSubCompound("BlockEntityTag");
		if(a==null||!a.hasKey("LinkX",99)||!a.hasKey("LinkY",99)||!a.hasKey("LinkZ",99))return;
		tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted("tile.control_panel_linkable",a.getInteger("LinkX"),a.getInteger("LinkY"),a.getInteger("LinkZ")));
	}
	@Override public EnumActionResult onItemUse(EntityPlayer player,World world,BlockPos pos,EnumHand hand,EnumFacing facing,float hitX,float hitY,float hitZ){
		if(player.isSneaking()){
			Block b=world.getBlockState(pos).getBlock();
			for(ITileEntityProvider a:link){
				if(b==a&&world.getTileEntity(pos)!=null){
					ItemStack s=player.getHeldItem(hand);
					NBTTagCompound n=s.getOrCreateSubCompound("BlockEntityTag");
					n.setInteger("LinkX",pos.getX());
					n.setInteger("LinkY",pos.getY());
					n.setInteger("LinkZ",pos.getZ());
					return EnumActionResult.SUCCESS;
				}
			}
		}
		return super.onItemUse(player,world,pos,hand,facing,hitX,hitY,hitZ);
	}
}