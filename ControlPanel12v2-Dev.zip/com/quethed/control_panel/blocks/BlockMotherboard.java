package com.quethed.control_panel.blocks;
import java.util.List;
import com.quethed.control_panel.TileEntityMotherboard;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class BlockMotherboard extends BlockContainer{
	public static float distanceLoss;
	public static int networkMax;
	public BlockMotherboard(){
		super(Material.CIRCUITS);
		setSoundType(SoundType.METAL);
	}
	@Override@SideOnly(Side.CLIENT)public void addInformation(ItemStack stack,World world,List<String>tooltip,net.minecraft.client.util.ITooltipFlag flag){
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown()){
			String l=I18n.translateToLocal(getUnlocalizedName()+".desc");
			String[] s=l.split("\\\\n");
			int i=1;
			for(String t:s){
				tooltip.add(i,t);
				i++;
			}
		}
		else tooltip.add(I18n.translateToLocal("moreInfo"));
	}
	@Override public boolean canProvidePower(IBlockState state){return true;}
	@Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,BlockHorizontal.FACING);}
	@Override public TileEntity createNewTileEntity(World world,int meta){return new TileEntityMotherboard();}
	@Override public int getMetaFromState(IBlockState state){return state.getValue(BlockHorizontal.FACING).getHorizontalIndex();}
	@Override public EnumPushReaction getMobilityFlag(IBlockState state){return EnumPushReaction.NORMAL;}
	@Override public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.MODEL;}
	@Override public IBlockState getStateFromMeta(int meta){
		return getDefaultState().withProperty(BlockHorizontal.FACING,meta<4?EnumFacing.HORIZONTALS[meta]:EnumFacing.SOUTH);
	}
	@Override public int getWeakPower(IBlockState state,IBlockAccess world,BlockPos pos,EnumFacing side){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityMotherboard){
			TileEntity e=((TileEntityMotherboard)t).getMasterTE();
			if(e!=null){
				int p=e.getBlockType().getWeakPower(world.getBlockState(e.getPos()),world,e.getPos(),side);
				p-=((TileEntityMotherboard)t).getMasterDistance()*distanceLoss;
				if(p<0)p=0;
				return p;
			}
		}
		return 0;
	}
	@Override public void onBlockPlacedBy(World world,BlockPos pos,IBlockState state,EntityLivingBase placer,ItemStack stack){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityMotherboard)((TileEntityMotherboard)t).setLink(placer,false);
	}
	@Override public IBlockState withMirror(IBlockState state,Mirror mirror){
		return state.withRotation(mirror.toRotation(state.getValue(BlockHorizontal.FACING)));
	}
	@Override public IBlockState withRotation(IBlockState state,Rotation rotation){
        return state.withProperty(BlockHorizontal.FACING,rotation.rotate(state.getValue(BlockHorizontal.FACING)));
	}
}
