package com.quethed.control_panel.blocks;
import java.util.List;
import java.util.Random;
import javax.annotation.Nullable;

import com.google.common.base.Predicate;
import com.quethed.control_panel.TileEntityGauge;
import net.minecraft.block.Block;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.BlockRedstoneWire;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockFaceShape;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.init.Blocks;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Mirror;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class BlockGauge extends BlockContainer{
	public static final PropertyDirection FACING=BlockHorizontal.FACING;
	protected static final AxisAlignedBB GAUGE_EAST_AABB=new AxisAlignedBB(0,0,0,0.1875,1,1);
	protected static final AxisAlignedBB GAUGE_WEST_AABB=new AxisAlignedBB(0.8125,0,0,1,1,1);
	protected static final AxisAlignedBB GAUGE_SOUTH_AABB=new AxisAlignedBB(0,0,0,1,1,0.1875);
	protected static final AxisAlignedBB GAUGE_NORTH_AABB=new AxisAlignedBB(0,0,0.8125,1,1,1);
	public static final PropertyInteger MEASUREMENT=PropertyInteger.create("measurement",0,15);
	public BlockGauge(){
		super(Material.GLASS);
		setSoundType(SoundType.GLASS);
		setHardness(.25f);
		setResistance(0);
	}
	@Override@SideOnly(Side.CLIENT)public void addInformation(net.minecraft.item.ItemStack stack,World world,java.util.List<String>tooltip,net.minecraft.client.util.ITooltipFlag flag){
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown()){
			String l=net.minecraft.util.text.translation.I18n.translateToLocal(getUnlocalizedName()+".desc");
			String[] s=l.split("\\\\n");
			int i=1;
			for(String t:s){
				tooltip.add(i,t);
				i++;
			}
		}
		else tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocal("moreInfo"));
	}
	public int calculateInputStrength(World world,BlockPos pos,IBlockState state){
		EnumFacing f=state.getValue(FACING).getOpposite();
		BlockPos p=pos.offset(f);
		int i=world.getRedstonePower(p,f);
		if(i<16){
			IBlockState s=world.getBlockState(p);
			i=Math.max(i,s.getBlock()==Blocks.REDSTONE_WIRE?s.getValue(BlockRedstoneWire.POWER):0);
		}
		IBlockState s=world.getBlockState(p);
		if(s.hasComparatorInputOverride())i=s.getComparatorInputOverride(world,p);
		else if(i<15&&s.isNormalCube()){
			p=p.offset(f);
			s=world.getBlockState(p);
			if(s.hasComparatorInputOverride())i=s.getComparatorInputOverride(world,p);
			else if(s.getMaterial()==Material.AIR){
				EntityItemFrame e=findItemFrame(world,f,p);
				if(e!=null)i=e.getAnalogOutput();
			}
		}
		return i;
	}
	@Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,FACING,MEASUREMENT);}
	@Override public TileEntity createNewTileEntity(World world,int meta){return new TileEntityGauge();}
	@Override public BlockFaceShape getBlockFaceShape(IBlockAccess world,IBlockState state,BlockPos pos,EnumFacing face){return BlockFaceShape.UNDEFINED;}
	@Override public boolean eventReceived(IBlockState state,World world,BlockPos pos,int id,int param){return world.getTileEntity(pos)!=null;}
	@Override public IBlockState getActualState(IBlockState state,IBlockAccess world,BlockPos pos){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityGauge)state=state.withProperty(MEASUREMENT,((TileEntityGauge)t).getOutputSignal());
		return state;
	}
	@Nullable private EntityItemFrame findItemFrame(World world,final EnumFacing facing,BlockPos pos){
		List<EntityItemFrame>l=world.<EntityItemFrame>getEntitiesWithinAABB(EntityItemFrame.class,new AxisAlignedBB(pos.getX(),pos.getY(),pos.getZ(),pos.getX()+1,pos.getY()+1,pos.getZ()+1),new Predicate<Entity>(){
			public boolean apply(@Nullable Entity entity){return entity!=null&&entity.getHorizontalFacing()==facing;}
		});
		return l.size()==1?(EntityItemFrame)l.get(0):null;
	}
	@Override public AxisAlignedBB getBoundingBox(IBlockState state,IBlockAccess source,BlockPos pos){
		switch(state.getValue(FACING)){
			case NORTH:return GAUGE_NORTH_AABB;
			case SOUTH:return GAUGE_SOUTH_AABB;
			case WEST:return GAUGE_WEST_AABB;
			case EAST:default:return GAUGE_EAST_AABB;
		}
	}
	@Override@SideOnly(Side.CLIENT)public BlockRenderLayer getBlockLayer(){return BlockRenderLayer.CUTOUT;}
	@Override public AxisAlignedBB getCollisionBoundingBox(IBlockState state,IBlockAccess world,BlockPos pos){return NULL_AABB;}
	@Override public int getMetaFromState(IBlockState state){return state.getValue(FACING).getHorizontalIndex();}
	@Override public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.MODEL;}
	@Override public IBlockState getStateForPlacement(World world,BlockPos pos,EnumFacing facing,float hitX,float hitY,float hitZ,int meta,net.minecraft.entity.EntityLivingBase placer){
		if(facing.getAxis()==EnumFacing.Axis.Y)facing=placer.getHorizontalFacing().getOpposite();
		return getDefaultState().withProperty(FACING,facing);
	}
	@Override public IBlockState getStateFromMeta(int meta){return getDefaultState().withProperty(FACING,EnumFacing.getHorizontal(meta%4));}
	@Override public boolean getWeakChanges(IBlockAccess world,BlockPos pos){return true;}
	@Override public boolean isFullCube(IBlockState state){return false;}
	@Override public boolean isOpaqueCube(IBlockState state){return false;}
	@Override public void onBlockAdded(World world,BlockPos pos,IBlockState state){neighborChanged(state,world,pos,this,pos);}
	@Override public void onNeighborChange(IBlockAccess world,BlockPos pos,BlockPos neighbor){
		if(pos.getY()==neighbor.getY()&&world instanceof World&&!((World)world).isRemote)
			neighborChanged(world.getBlockState(pos),(World)world,pos,world.getBlockState(neighbor).getBlock(),neighbor);
	}
	@Override public void neighborChanged(IBlockState state,World world,BlockPos pos,Block block,BlockPos fromPos){
		com.quethed.control_panel.ControlPanelServer.neighborChangedGauge(null,state,world,pos,block,fromPos);
	}
	@Override public void updateTick(World world,BlockPos pos,IBlockState state,Random random){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityGauge)((TileEntityGauge)t).setOutputSignal(calculateInputStrength(world,pos,state));
	}
	@Override public IBlockState withMirror(IBlockState state,Mirror mirror){
		return state.withRotation(mirror.toRotation(state.getValue(FACING)));
	}
	@Override public IBlockState withRotation(IBlockState state,Rotation rot){
		return state.withProperty(FACING,rot.rotate(state.getValue(FACING)));
	}
}