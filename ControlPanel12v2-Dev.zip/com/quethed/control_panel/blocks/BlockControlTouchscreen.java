package com.quethed.control_panel.blocks;
import com.quethed.control_panel.TileEntityControlPanelTouchscreen;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class BlockControlTouchscreen extends BlockControl{
	@Override@SideOnly(Side.CLIENT)public void addInformation(net.minecraft.item.ItemStack stack,World world,java.util.List<String>tooltip,net.minecraft.client.util.ITooltipFlag flag){
		super.addInformation(stack,world,tooltip,flag);
		net.minecraft.nbt.NBTTagCompound a=stack.getSubCompound("BlockEntityTag");
		if(a==null)return;
		if(flag.isAdvanced()){
			if(a.hasKey("BackgroundColor",99)){
				int c=a.getInteger("BackgroundColor");
				if(c>=0)tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted("item.color.background",String.format("#%06X",c)));
			}
			if(a.hasKey("ForegroundColor",99)){
				int c=a.getInteger("ForegroundColor");
				if(c>=0)tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted("item.color.foreground",String.format("#%06X",c)));
			}
		}
		else{
			if(a.hasKey("BackgroundColor",99)&&a.getInteger("BackgroundColor")>=0)
				tooltip.add(net.minecraft.util.text.TextFormatting.ITALIC+net.minecraft.util.text.translation.I18n.translateToLocal("item.dyed"));
			else if(a.hasKey("ForegroundColor",99)&&a.getInteger("ForegroundColor")>=0)
				tooltip.add(net.minecraft.util.text.TextFormatting.ITALIC+net.minecraft.util.text.translation.I18n.translateToLocal("item.dyed"));
		}
	}
	@Override public TileEntity createNewTileEntity(World world,int meta){return new TileEntityControlPanelTouchscreen();}
}