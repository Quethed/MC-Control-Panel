package com.quethed.control_panel.client;
import com.quethed.control_panel.TileEntityControlPanelTouchscreen;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.color.IBlockColor;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)public class TouchscreenBlockColor implements IBlockColor{
	@Override public int colorMultiplier(IBlockState state,IBlockAccess world,BlockPos pos,int tintIndex){
		switch(tintIndex){
			case 0:
				TileEntity a=world.getTileEntity(pos);
				if(a instanceof TileEntityControlPanelTouchscreen)
					return((TileEntityControlPanelTouchscreen)a).getBackColor();
				break;
			case 1:
				TileEntity b=world.getTileEntity(pos);
				if(b instanceof TileEntityControlPanelTouchscreen)
					return((TileEntityControlPanelTouchscreen)b).getForeColor();
		}
		return-1;
	}
}