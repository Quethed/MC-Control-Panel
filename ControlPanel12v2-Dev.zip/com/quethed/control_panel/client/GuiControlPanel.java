package com.quethed.control_panel.client;
import java.util.ArrayList;
import com.quethed.control_panel.ControlPanel;
import com.quethed.control_panel.ControlPanelSideInfo;
import com.quethed.control_panel.ItemRemote;
import com.quethed.control_panel.TileEntityControlPanel;
import com.quethed.control_panel.messages.MessageControlPanel;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.translation.I18n;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)public class GuiControlPanel extends GuiScreen{
    static final ResourceLocation GUI_TEXTURE=new ResourceLocation("control_panel","textures/gui/control_panel.png");
	protected final ArrayList<EnumFacing>directions=new ArrayList<EnumFacing>();
	protected final ArrayList<GuiButton>panelButtons=new ArrayList<GuiButton>();
	public int range;
	public boolean remote;
	public final TileEntityControlPanel te;
	protected int xSize;
	protected int ySize;
	public GuiControlPanel(TileEntityControlPanel te,boolean remote,int range){
		this.range=range;
		this.remote=remote;
		this.te=te;
	}
	@Override public void actionPerformed(GuiButton button){
		EnumFacing f=directions.get(button.id);
		te.useSide(f);
		BlockPos p=te.getPos();
		ControlPanel.CHANNEL.sendToServer(new MessageControlPanel(p.getX(),p.getY(),p.getZ(),f));
	}
	@Override public boolean doesGuiPauseGame(){return false;}
	@Override public void drawScreen(int mouseX,int mouseY,float partialTicks){
		if(te.isInvalid()){
			mc.displayGuiScreen(null);
			return;
		}
		BlockPos a=te.getPos();
		if(remote){
			if(!ItemRemote.isInRange(a,mc.player.getPosition(),range)){
				mc.displayGuiScreen(null);
				return;
			}
		}
		else if(mc.player.getDistanceSq(a.getX()+.5,a.getY()+.5,a.getZ()+.5)>range){
			mc.displayGuiScreen(null);
			return;
		}
		GlStateManager.color(1,1,1,1);
		mc.getTextureManager().bindTexture(GUI_TEXTURE);
		int i=(this.width-this.xSize)/2;
		int j=(this.height-this.ySize)/2;
		int d=directions.size();
		int x=d>4||d==3?0:100;
		int y=d==6||d==4?0:d==3||d==2?76:122;
		drawTexturedModalRect(i,j,x,y,xSize,ySize);
		super.drawScreen(mouseX,mouseY,partialTicks);
		String s=te.getDisplayName().getUnformattedText();
		fontRenderer.drawString(s,width/2-fontRenderer.getStringWidth(s)/2,j+6,4210752);
		for(int b=0;b<buttonList.size();b++){
			if(buttonList.get(b) instanceof GuiControlPanelButton&&buttonList.get(b).isMouseOver())
				drawHoveringText(buttonList.get(b).displayString,mouseX,mouseY);
		}
	}
	@Override public void initGui(){
		for(GuiButton a:panelButtons)
			buttonList.remove(a);
		directions.clear();
		panelButtons.clear();
		for(EnumFacing s:EnumFacing.VALUES){
			ControlPanelSideInfo i=te.getSide(s);
			if(i!=null)directions.add(s);
		}
		int a=width/2;
		int c=height/2+3;
		int d=directions.size();
		for(int b=0;b<d;b++){
			int x=a;
			int y=b;
			switch(b){
			case 0:
				x=d>4||d==3?a-40:d==1?a-10:a-25;
				y=d>3?c-25:c-10;
				break;
			case 1:
				x=d>4||d==3?a-10:a+5;
				y=d<4||d==5?c-10:c-25;
				break;
			case 2:
				x=d==4?a-25:a+20;
				y=d==3?c-10:d==4?c+5:c-25;
				break;
			case 3:
				x=d==4?a+5:a-40;
				y=c+5;
				break;
			case 4:
				x=d==5?a+20:a-10;
				y=c+5;
				break;
			case 5:
				x=a+20;
				y=c+5;
				break;
			}
			ControlPanelSideInfo s=te.getSide(directions.get(b));
			String n=s.name.matches("")?I18n.translateToLocal("container.control_panel."+directions.get(b).getOpposite().toString()):s.name;
			GuiButton f=new GuiControlPanelButton(b,x,y,n,te.getSide(directions.get(b)));
			buttonList.add(f);
			panelButtons.add(f);
		}
		xSize=d>4||d==3?100:d==1?40:70;
		ySize=d>3?76:46;
		if(d<1)Minecraft.getMinecraft().displayGuiScreen(null);
	}
}