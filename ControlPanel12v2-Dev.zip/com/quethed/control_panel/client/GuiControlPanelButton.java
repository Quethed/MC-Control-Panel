package com.quethed.control_panel.client;
import com.quethed.control_panel.ControlPanelSideInfo;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)public class GuiControlPanelButton extends GuiButton{
	protected ControlPanelSideInfo info;
	public GuiControlPanelButton(int buttonId,int x,int y,String buttonText,ControlPanelSideInfo info){
		super(buttonId,x,y,20,20,buttonText);
		this.info=info;
	}
	@Override public void drawButton(Minecraft mc,int mouseX,int mouseY,float partialTicks){
		if(visible){
			mc.getTextureManager().bindTexture(GuiControlPanel.GUI_TEXTURE);
			int i=info.powered?210:170;
			hovered=mouseX>=x&&mouseY>=y&&mouseX<x+width&&mouseY<y+height;
			if(hovered)i+=20;
			drawTexturedModalRect(x,y,i,info.leverMode?20:0,20,20);
		}
	}
}