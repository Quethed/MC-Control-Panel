package com.quethed.control_panel.client;
import com.quethed.control_panel.TileEntityControlPanelTouchscreen;
import net.minecraft.client.renderer.color.IItemColor;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)public class TouchscreenItemColor implements IItemColor{
	@Override public int colorMultiplier(ItemStack stack,int tintIndex){
		switch(tintIndex){
			case 0:
				NBTTagCompound n=stack.getSubCompound("BlockEntityTag");
				if(n==null||!n.hasKey("BackgroundColor",99))return TileEntityControlPanelTouchscreen.DEFAULT_BACKGROUND_COLOR;
				int a=n.getInteger("BackgroundColor");
				if(a<0)return TileEntityControlPanelTouchscreen.DEFAULT_BACKGROUND_COLOR;
				return a;
			case 1:
				NBTTagCompound b=stack.getSubCompound("BlockEntityTag");
				if(b==null||!b.hasKey("ForegroundColor",99))return TileEntityControlPanelTouchscreen.DEFAULT_FOREGROUND_COLOR;
				int c=b.getInteger("ForegroundColor");
				if(c<0)return TileEntityControlPanelTouchscreen.DEFAULT_FOREGROUND_COLOR;
				return c;
			default:return-1;
		}
	}
}