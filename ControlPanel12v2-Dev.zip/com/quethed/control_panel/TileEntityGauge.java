package com.quethed.control_panel;
import javax.annotation.Nullable;
import com.quethed.control_panel.blocks.BlockGauge;
import com.quethed.control_panel.blocks.BlockGaugeComparator;
import net.minecraft.block.Block;
import net.minecraft.block.BlockHorizontal;
import net.minecraft.block.BlockRedstoneComparator;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityComparator;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
public class TileEntityGauge extends TileEntityComparator{
	private BlockPos link;
	public BlockPos getLink(){return link==null?null:ControlPanel.rotate(pos.up(link.getY()),link.getX(),link.getZ(),ControlPanel.getRotation(world.getBlockState(pos).getValue(BlockHorizontal.FACING)));}
	@Override@Nullable public SPacketUpdateTileEntity getUpdatePacket(){return new SPacketUpdateTileEntity(pos,1,getUpdateTag());}
	@Override public NBTTagCompound getUpdateTag(){return writeToNBT(new NBTTagCompound());}
	@Override public void handleUpdateTag(NBTTagCompound tag){
		int m=getOutputSignal();
		super.handleUpdateTag(tag);
		if(m!=getOutputSignal())world.markBlockRangeForRenderUpdate(pos,pos);
	}
	@Override public void onDataPacket(NetworkManager net,SPacketUpdateTileEntity pkt){
		handleUpdateTag(pkt.getNbtCompound());
    }
	@Override public void readFromNBT(NBTTagCompound compound){
		if(compound.hasKey("LinkX",3)&&compound.hasKey("LinkY",3)&&compound.hasKey("LinkZ",3)){
			link=new BlockPos(compound.getInteger("LinkX"),compound.getInteger("LinkY"),compound.getInteger("LinkZ"));
			setComparatorLink();
		}
		if(compound.hasKey("RelativeLinkX",3)&&compound.hasKey("RelativeLinkY",3)&&compound.hasKey("RelativeLinkZ",3)){
			link=new BlockPos(compound.getInteger("RelativeLinkX"),compound.getInteger("RelativeLinkY"),compound.getInteger("RelativeLinkZ"));
		}
		super.readFromNBT(compound);
	}
	@Override public boolean receiveClientEvent(int id,int type){return true;}
	private void rotateLink(){//I cannot flip the z axis for unknown reasons. ControlPanel.getRotation(EnumFacing) is likely calibrated wrong.
		EnumFacing f=world.getBlockState(pos).getValue(BlockHorizontal.FACING);
		if(f.getAxis()==EnumFacing.Axis.X)f=f.getOpposite();
		link=ControlPanel.rotate(new BlockPos(0,link.getY(),0),link.getX(),link.getZ(),ControlPanel.getRotation(f));
	}
	private void setComparatorLink(){
		IBlockState s=world.getBlockState(link);
		Block b=s.getBlock();
		if((b==Blocks.POWERED_COMPARATOR||b==Blocks.UNPOWERED_COMPARATOR)&&world.getTileEntity(link) instanceof TileEntityComparator){
			if(s==Blocks.POWERED_COMPARATOR)world.setBlockState(link,ModBlocks.POWERED_GAUGE_COMPARATOR.getDefaultState().withProperty(BlockHorizontal.FACING,s.getValue(BlockHorizontal.FACING)).withProperty(BlockRedstoneComparator.POWERED,s.getValue(BlockRedstoneComparator.POWERED)).withProperty(BlockRedstoneComparator.MODE,s.getValue(BlockRedstoneComparator.MODE)));
			else world.setBlockState(link,ModBlocks.UNPOWERED_GAUGE_COMPARATOR.getDefaultState().withProperty(BlockHorizontal.FACING,s.getValue(BlockHorizontal.FACING)).withProperty(BlockRedstoneComparator.POWERED,s.getValue(BlockRedstoneComparator.POWERED)).withProperty(BlockRedstoneComparator.MODE,s.getValue(BlockRedstoneComparator.MODE)));
			TileEntity t=world.getTileEntity(link);
			link=new BlockPos(link.getX()-pos.getX(),link.getY()-pos.getY(),link.getZ()-pos.getZ());
			if(t instanceof TileEntityGauge){
				((TileEntityGauge)t).link=new BlockPos(-link.getX(),-link.getY(),-link.getZ());
				rotateLink();
				((TileEntityGauge)t).rotateLink();
			}
			else{
				link=null;
			}
		}
		else{
			link=null;
		}
	}
	@Override public void setOutputSignal(int outputSignal){
		super.setOutputSignal(outputSignal);
		IBlockState s=world.getBlockState(pos);
		if(s.getBlock()instanceof BlockGaugeComparator){
			BlockPos p=getLink();
			if(p==null)return;
			TileEntity t=world.getTileEntity(p);
			if(t instanceof TileEntityGauge&&t.getBlockType()instanceof BlockGauge)((TileEntityGauge)t).setOutputSignal(getOutputSignal());
		}
		world.notifyBlockUpdate(pos,s,s,2);
	}
	@Override public boolean shouldRefresh(World world,BlockPos pos,IBlockState oldState,IBlockState newState){
		Block b=oldState.getBlock();
        return b instanceof BlockGauge?oldState!=newState:newState.getBlock()instanceof BlockGaugeComparator?!getBlockType().isAssociatedBlock(b):true;
    }
	@Override public NBTTagCompound writeToNBT(NBTTagCompound compound){
		if(link==null)return super.writeToNBT(compound);
		compound.setInteger("RelativeLinkX",link.getX());
		compound.setInteger("RelativeLinkY",link.getY());
		compound.setInteger("RelativeLinkZ",link.getZ());
		return super.writeToNBT(compound);
	}
}