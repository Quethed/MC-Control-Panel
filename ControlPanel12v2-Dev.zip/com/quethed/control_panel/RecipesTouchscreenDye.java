package com.quethed.control_panel;
import java.util.ArrayList;
import net.minecraft.init.Items;
import net.minecraft.inventory.InventoryCrafting;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.oredict.DyeUtils;
import net.minecraftforge.registries.IForgeRegistryEntry;
public class RecipesTouchscreenDye extends IForgeRegistryEntry.Impl<IRecipe>implements IRecipe{
	static boolean CAN_FLIP_FRAME=true;
	private final Item DARK,LIGHT;
	public RecipesTouchscreenDye(Item light,Item dark){
		LIGHT=light;
		DARK=dark;
	}
	private void blendColor(ItemStack stack,boolean foreground,int[]ints){
		NBTTagCompound n=stack.getOrCreateSubCompound("BlockEntityTag");
		int a=n.getInteger((foreground?"Fore":"Back")+"groundColor");
		float f=(a>>16&255)/255f;
		float b=(a>>8&255)/255f;
		float c=(a&255)/255f;
		ints[3]=(int)(ints[3]+Math.max(f,Math.max(b,c))*255);
		ints[0]=(int)(ints[0]+f*255);
		ints[1]=(int)(ints[1]+b*255);
		ints[2]=(int)(ints[2]+c*255);
		ints[4]++;
	}
	private void blendColor(ItemStack dye,int[]ints){
		float[]a=DyeUtils.colorFromStack(dye).get().getColorComponentValues();
		int b=(int)(a[0]*255);
		int c=(int)(a[1]*255);
		int d=(int)(a[2]*255);
		ints[3]+=Math.max(b,Math.max(c,d));
		ints[0]+=b;
		ints[1]+=c;
		ints[2]+=d;
		ints[4]++;
	}
	@Override public boolean canFit(int width,int height){return width>0&&height>1;}
	private void finalBlendColors(ItemStack stack,boolean foreground,int[]ints){
		int j=ints[4];
		int a=ints[0]/j;
		int b=ints[1]/j;
		int c=ints[2]/j;
		float d=(float)ints[3]/(float)j;
		float f=(float)Math.max(a,Math.max(b,c));
		a=(int)(a*d/f);
		b=(int)(b*d/f);
		c=(int)(c*d/f);
		int g=(a<<8)+b;
		g=(g<<8)+c;
		stack.getSubCompound("BlockEntityTag").setInteger((foreground?"Fore":"Back")+"groundColor",g);
	}
	@Override public ItemStack getCraftingResult(InventoryCrafting inv){
		ArrayList<ItemStack>a=new ArrayList<ItemStack>();
		ItemStack b=null;
		boolean c=false;
		ArrayList<ItemStack>d=new ArrayList<ItemStack>();
		for(int y=0;y<inv.getHeight();y++){
			ArrayList<ItemStack>f=new ArrayList<ItemStack>();
			boolean g=false;
			for(int x=0;x<inv.getWidth();x++){
				ItemStack h=inv.getStackInRowAndColumn(x,y);
				if(h.isEmpty())continue;
				Item i=h.getItem();
				if(i==LIGHT||i==DARK){
					if(b!=null)return null;
					b=h;
					g=true;
				}
				else if(DyeUtils.isDye(h))f.add(h);
				else return null;
			}
			if(g){
				int h=f.size();
				if(!CAN_FLIP_FRAME){
					if(h>0)return null;
					continue;
				}
				if(h>1)return null;
				if(h<1)continue;
				ItemStack i=f.get(0);
				if(i.getItem()!=Items.DYE)return null;
				Item j=b.getItem();
				int k=i.getMetadata();
				if(j==LIGHT&&k==0)c=true;
				else if(j==DARK&&k==15)c=true;
				else return null;
			}
			else if(b==null)a.addAll(f);
			else d.addAll(f);
		}
		if(b==null)return null;
		if(d.size()<0&&a.size()<0&&!c)return null;
		ItemStack r;
		if(c){//Please note that capabilities are not copied here.
			r=new ItemStack(b.getItem()==LIGHT?DARK:LIGHT,b.getCount(),b.getItemDamage());
			r.setAnimationsToGo(b.getAnimationsToGo());
			if(b.hasTagCompound())r.setTagCompound(b.getTagCompound().copy());
		}
		else r=b.copy();
		if(d.size()>0){
			int[]f=new int[5];
			blendColor(r,false,f);
			for(ItemStack g:d)blendColor(g,f);
			finalBlendColors(r,false,f);
		}
		if(a.size()>0){
			int[]f=new int[5];
			blendColor(r,true,f);
			for(ItemStack g:a)blendColor(g,f);
			finalBlendColors(r,true,f);
		}
		return r;
	}
	@Override public ItemStack getRecipeOutput(){return new ItemStack(LIGHT);}
	@Override public boolean matches(InventoryCrafting inv,World world){return getCraftingResult(inv)!=null;}
}