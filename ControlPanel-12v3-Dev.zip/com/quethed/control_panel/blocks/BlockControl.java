package com.quethed.control_panel.blocks;
import java.util.ArrayList;
import java.util.Random;
import com.quethed.control_panel.ControlPanelSideInfo;
import com.quethed.control_panel.ItemRemote;
import com.quethed.control_panel.TileEntityControlPanel;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.EnumPushReaction;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.PropertyDirection;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemNameTag;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.EnumHand;
import net.minecraft.util.Mirror;
import net.minecraft.util.NonNullList;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class BlockControl extends BlockContainer{
	public static Item LEVER=Item.getItemFromBlock(Blocks.LEVER);
	public static Item BUTTON=Item.getItemFromBlock(Blocks.STONE_BUTTON);
	public static boolean DROPS_WITH_DATA;
	public static final ArrayList<Item>EXTRACT=new ArrayList<Item>();
    public static final PropertyDirection FACING=PropertyDirection.create("horizontal_facing",EnumFacing.Plane.HORIZONTAL);
	public BlockControl(){
		super(Material.IRON);
		setSoundType(SoundType.METAL);
	}
	@Override@SideOnly(Side.CLIENT)public void addInformation(ItemStack stack,World world,java.util.List<String>tooltip,net.minecraft.client.util.ITooltipFlag flag){
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown()){
			String l=net.minecraft.util.text.translation.I18n.translateToLocal("tile."+getUnlocalizedDescription()+".desc");
			String[] s=l.split("\\\\n");
			int i=1;
			for(String t:s){
				tooltip.add(i,t);
				i++;
			}
		}
		else tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocal("moreInfo"));
	}
	@Override public void breakBlock(World world,BlockPos pos,IBlockState state){
		com.quethed.control_panel.ControlPanelServer.breakControlBlock(this,world,pos,state);
		super.breakBlock(world,pos,state);
	}
	@Override public boolean canHarvestBlock(IBlockAccess world,BlockPos pos,EntityPlayer player){return true;}
	@Override public boolean canProvidePower(IBlockState state){return true;}
	@Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,BlockDirectional.FACING,FACING);}
	@Override public TileEntity createNewTileEntity(World world,int meta){return new TileEntityControlPanel();}
	@Override public void dropBlockAsItemWithChance(World world,BlockPos pos,IBlockState state,float chance,int fortune){}
	@Override@SideOnly(Side.CLIENT)public BlockRenderLayer getBlockLayer(){return BlockRenderLayer.TRANSLUCENT;}
	@Override@Deprecated public void getDrops(NonNullList<ItemStack>drops,IBlockAccess world,BlockPos pos,IBlockState state,int fortune){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityControlPanel){
			TileEntityControlPanel e=(TileEntityControlPanel)t;
			ItemStack b=e.getItemDropped(this);
			if(e.hasCustomName())b.setStackDisplayName(e.getName());
			if(DROPS_WITH_DATA){
				for(int a=0;a<6;a++){
					if(e.getSide(a)==null)continue;
					e.writeSides(b.getOrCreateSubCompound("BlockEntityTag"));
					break;
				}
			}
			drops.add(b);
			if(DROPS_WITH_DATA)return;
			for(int a=0;a<6;a++){
				ControlPanelSideInfo i=e.getSide(a);
				if(i!=null){
					ItemStack s=new ItemStack(i.leverMode?LEVER:BUTTON);
					if(!i.name.matches(""))s.setStackDisplayName(i.name);
					drops.add(s);
				}
			}
		}
    }
	@Override public Item getItemDropped(IBlockState state,Random random,int fortune){return Items.AIR;}
	@Override public int getMetaFromState(IBlockState state){
		int m=state.getValue(BlockDirectional.FACING).getIndex();
		switch(state.getValue(FACING)){
			case SOUTH:
				if(m==0)m=1;
				else if(m==1)m=0;
				return m;
			case WEST:
				if(m==0)m=9;
				else if(m==1)m=6;
				return m;
			case NORTH:
				if(m==0)m=10;
				else if(m==1)m=7;
				return m;
			case EAST:
				if(m==0)m=11;
				else if(m==1)m=8;
				return m;
			default:return m;
		}
	}
	@Override public EnumPushReaction getMobilityFlag(IBlockState state){return EnumPushReaction.NORMAL;}
	@Override public EnumBlockRenderType getRenderType(IBlockState state){return EnumBlockRenderType.MODEL;}
	@Override public IBlockState getStateForPlacement(World world,BlockPos pos,EnumFacing facing,float hitX,float hitY,float hitZ,int meta,EntityLivingBase placer){
		if(facing.getHorizontalIndex()!=-1)return getDefaultState().withProperty(BlockDirectional.FACING,facing).withProperty(FACING,facing);
		return getDefaultState().withProperty(BlockDirectional.FACING,facing).withProperty(FACING,placer.getHorizontalFacing());
	}
	@Override public IBlockState getStateFromMeta(int meta){
		return getDefaultState().withProperty(BlockDirectional.FACING,meta==0?EnumFacing.UP:meta==1?EnumFacing.DOWN:meta<6?EnumFacing.VALUES[meta]:meta<9?EnumFacing.UP:EnumFacing.DOWN).withProperty(FACING,meta<2?EnumFacing.SOUTH:meta<6?EnumFacing.VALUES[meta]:meta<9?EnumFacing.HORIZONTALS[meta-5]:meta<12?EnumFacing.HORIZONTALS[meta-8]:EnumFacing.SOUTH);
	}
	@SideOnly(Side.CLIENT)public String getUnlocalizedDescription(){return"controlPanel";}
	@Override public int getWeakPower(IBlockState state,IBlockAccess world,BlockPos pos,EnumFacing side){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityControlPanel){
			ControlPanelSideInfo i=((TileEntityControlPanel)t).getSide(side);
			return i!=null&&i.powered?15:0;
		}
		return 0;
	}
	@Override public boolean onBlockActivated(World world,BlockPos pos,IBlockState state,EntityPlayer player,EnumHand hand,EnumFacing facing,float hitX,float hitY,float hitZ){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityControlPanel){
			TileEntityControlPanel e=(TileEntityControlPanel)t;
			ItemStack s=player.getHeldItem(hand);
			if(s.getItem()instanceof ItemRemote){
				((ItemRemote)s.getItem()).linkToTileEntity(s,e);
				return true;
			}
			if(s.getItem()==BUTTON||s.getItem()==LEVER||EXTRACT.contains(s.getItem())||s.getItem()instanceof ItemNameTag){
				e.replaceSide(world,s,facing.getOpposite(),!player.capabilities.isCreativeMode,player);
				return true;
			}
			if(world.isRemote)net.minecraft.client.Minecraft.getMinecraft().displayGuiScreen(new com.quethed.control_panel.client.GuiControlPanel(e,false,64));
		}
		return true;
	}
	@Override public void onBlockHarvested(World world,BlockPos pos,IBlockState state,EntityPlayer player){
		TileEntity a=world.getTileEntity(pos);
		if(a instanceof TileEntityControlPanel){
			if(player.capabilities.isCreativeMode)
				world.removeTileEntity(pos);
		}
	}
	@Override public void onBlockPlacedBy(World world,BlockPos pos,IBlockState state,EntityLivingBase player,ItemStack stack){
		if(stack.hasDisplayName()){
			TileEntity t=world.getTileEntity(pos);
			if(t instanceof TileEntityControlPanel)
				((TileEntityControlPanel)t).setCustomName(stack.getDisplayName());
		}
	}
	@Override public IBlockState withMirror(IBlockState state,Mirror mirror){
		return state.withRotation(mirror.toRotation(state.getValue(FACING)));
	}
	@Override public IBlockState withRotation(IBlockState state,Rotation rotation){
		EnumFacing a=rotation.rotate(state.getValue(FACING));
		EnumFacing b=state.getValue(BlockDirectional.FACING);
		if(b.getAxis()!=EnumFacing.Axis.Y)b=a;
        return state.withProperty(FACING,a).withProperty(BlockDirectional.FACING,b);
	}
}