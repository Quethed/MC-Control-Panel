package com.quethed.control_panel.blocks;
import com.quethed.control_panel.ModBlocks;
import com.quethed.control_panel.TileEntityGauge;
import net.minecraft.block.BlockRedstoneComparator;
import net.minecraft.block.SoundType;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;
public class BlockGaugeComparator extends BlockRedstoneComparator{
	public static final PropertyInteger MEASUREMENT=BlockGauge.MEASUREMENT;
	public BlockGaugeComparator(boolean powered){
		super(powered);
		setSoundType(SoundType.WOOD);
		disableStats();
	}
	@Override protected BlockStateContainer createBlockState(){return new BlockStateContainer(this,FACING,MODE,POWERED,MEASUREMENT);}
	@Override public TileEntity createNewTileEntity(World world,int meta){return new TileEntityGauge();}
	@Override public IBlockState getActualState(IBlockState state,IBlockAccess world,BlockPos pos){
		TileEntity t=world.getTileEntity(pos);
		if(t instanceof TileEntityGauge)state=state.withProperty(MEASUREMENT,((TileEntityGauge)t).getOutputSignal());
		return state;
	}
	@Override protected IBlockState getPoweredState(IBlockState unpoweredState){return ModBlocks.POWERED_GAUGE_COMPARATOR.getDefaultState().withProperty(FACING,unpoweredState.getValue(FACING)).withProperty(POWERED,unpoweredState.getValue(POWERED)).withProperty(MODE,unpoweredState.getValue(MODE));}
	@Override protected IBlockState getUnpoweredState(IBlockState poweredState){return ModBlocks.UNPOWERED_GAUGE_COMPARATOR.getDefaultState().withProperty(FACING,poweredState.getValue(FACING)).withProperty(POWERED,poweredState.getValue(POWERED)).withProperty(MODE,poweredState.getValue(MODE));}
}