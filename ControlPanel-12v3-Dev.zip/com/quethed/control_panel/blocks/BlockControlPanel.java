package com.quethed.control_panel.blocks;
import net.minecraft.block.BlockDirectional;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
public class BlockControlPanel extends BlockControl{
	public static final AxisAlignedBB DOWN_X_BOUNDS=new AxisAlignedBB(.25,.9375,.125,.75,1,.875);
	public static final AxisAlignedBB DOWN_Z_BOUNDS=new AxisAlignedBB(.125,.9375,.25,.875,1,.75);
	public static final AxisAlignedBB EAST_BOUNDS=new AxisAlignedBB(0,.25,.125,.0625,.75,.875);
	public static final AxisAlignedBB NORTH_BOUNDS=new AxisAlignedBB(.125,.25,.9375,.875,.75,1);
	public static final AxisAlignedBB SOUTH_BOUNDS=new AxisAlignedBB(.125,.25,0,.875,.75,.0625);
	public static final AxisAlignedBB UP_X_BOUNDS=new AxisAlignedBB(.25,0,.125,.75,.0625,.875);
	public static final AxisAlignedBB UP_Z_BOUNDS=new AxisAlignedBB(.125,0,.25,.875,.0625,.75);
	public static final AxisAlignedBB WEST_BOUNDS=new AxisAlignedBB(.9375,.25,.125,1,.75,.875);
	@Override public AxisAlignedBB getBoundingBox(IBlockState state,IBlockAccess source,BlockPos pos){
		switch(state.getValue(BlockDirectional.FACING)){
			case EAST:return EAST_BOUNDS;
			case NORTH:return NORTH_BOUNDS;
			case SOUTH:return SOUTH_BOUNDS;
			case UP:return state.getValue(FACING).getAxis()==EnumFacing.Axis.Z?UP_Z_BOUNDS:UP_X_BOUNDS;
			case WEST:return WEST_BOUNDS;
			default:return state.getValue(FACING).getAxis()==EnumFacing.Axis.Z?DOWN_Z_BOUNDS:DOWN_X_BOUNDS;
		}
	}
	@Override public boolean isFullCube(IBlockState state){return false;}
	@Override public boolean isOpaqueCube(IBlockState state){return false;}
}