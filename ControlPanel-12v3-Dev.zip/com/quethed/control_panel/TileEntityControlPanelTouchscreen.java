package com.quethed.control_panel;
import javax.annotation.Nullable;
import com.quethed.control_panel.blocks.BlockControl;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class TileEntityControlPanelTouchscreen extends TileEntityControlPanel{
	@SideOnly(Side.CLIENT)public static int DEFAULT_BACKGROUND_COLOR,DEFAULT_FOREGROUND_COLOR;
	protected int backColor=-1;
	protected int foreColor=-1;
	@SideOnly(Side.CLIENT)public int getBackColor(){
		if(backColor<0)return DEFAULT_BACKGROUND_COLOR;
		return backColor;
	}
	@SideOnly(Side.CLIENT)public int getForeColor(){
		if(foreColor<0)return DEFAULT_FOREGROUND_COLOR;
		return foreColor;
	}
	@Override public ItemStack getItemDropped(BlockControl block){
		ItemStack r=new ItemStack(block);
		if(backColor>=0||foreColor>=0){
			NBTTagCompound n=new NBTTagCompound();
			NBTTagCompound b=new NBTTagCompound();
			if(backColor>=0)b.setInteger("BackgroundColor",backColor);
			if(foreColor>=0)b.setInteger("ForegroundColor",foreColor);
			n.setTag("BlockEntityTag",b);
			r.setTagCompound(n);
		}
		return r;
	}
	@Override@Nullable public SPacketUpdateTileEntity getUpdatePacket(){return new SPacketUpdateTileEntity(pos,1,getUpdateTag());}
	@Override public void handleUpdateTag(NBTTagCompound tag){
		super.handleUpdateTag(tag);
		world.markBlockRangeForRenderUpdate(pos,pos);
	}
	@Override public void readFromNBT(NBTTagCompound compound){
		super.readFromNBT(compound);
		if(compound.hasKey("BackgroundColor",99))backColor=compound.getInteger("BackgroundColor");
		else backColor=-1;
		if(compound.hasKey("ForegroundColor",99))foreColor=compound.getInteger("ForegroundColor");
		else foreColor=-1;
	}
	@Override public boolean receiveClientEvent(int id,int type){return true;}
	@Override public NBTTagCompound writeToNBT(NBTTagCompound compound){
		compound=super.writeToNBT(compound);
		if(backColor>=0)compound.setInteger("BackgroundColor",backColor);
		if(foreColor>=0)compound.setInteger("ForegroundColor",foreColor);
		return compound;
	}
}