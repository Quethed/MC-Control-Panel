package com.quethed.control_panel.client;
import com.quethed.control_panel.ModBlocks;
import com.quethed.control_panel.ModItems;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraftforge.client.event.ColorHandlerEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
@SideOnly(Side.CLIENT)public class ControlPanelClient{
	@SubscribeEvent public void registerBlockColors(ColorHandlerEvent.Block event){
		event.getBlockColors().registerBlockColorHandler(new TouchscreenBlockColor(),ModBlocks.DARK_TOUCHSCREEN_CONTROL_BLOCK,ModBlocks.DARK_TOUCHSCREEN_CONTROL_PANEL,ModBlocks.TOUCHSCREEN_CONTROL_BLOCK,ModBlocks.TOUCHSCREEN_CONTROL_PANEL);
	}
	@SubscribeEvent public void registerItemColors(ColorHandlerEvent.Item event){
		event.getItemColors().registerItemColorHandler(new TouchscreenItemColor(),ModItems.DARK_TOUCHSCREEN_CONTROL_BLOCK,ModItems.DARK_TOUCHSCREEN_CONTROL_PANEL,ModItems.TOUCHSCREEN_CONTROL_BLOCK,ModItems.TOUCHSCREEN_CONTROL_PANEL);
	}
	@SubscribeEvent public void registerRenders(ModelRegistryEvent event){
		ModelLoader.setCustomModelResourceLocation(ModItems.CONTROL_BLOCK,0,new ModelResourceLocation("controlpanel:control_block","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.CONTROL_PANEL,0,new ModelResourceLocation("controlpanel:control_panel","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.DARK_CONTROL_BLOCK,0,new ModelResourceLocation("controlpanel:dark_control_block","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.DARK_CONTROL_PANEL,0,new ModelResourceLocation("controlpanel:dark_control_panel","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.TOUCHSCREEN_CONTROL_BLOCK,0,new ModelResourceLocation("controlpanel:touchscreen_control_block","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.TOUCHSCREEN_CONTROL_PANEL,0,new ModelResourceLocation("controlpanel:touchscreen_control_panel","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.DARK_TOUCHSCREEN_CONTROL_BLOCK,0,new ModelResourceLocation("controlpanel:dark_touchscreen_control_block","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.DARK_TOUCHSCREEN_CONTROL_PANEL,0,new ModelResourceLocation("controlpanel:dark_touchscreen_control_panel","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.MOTHERBOARD,0,new ModelResourceLocation("controlpanel:motherboard","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.REDSTONE_GAUGE,0,new ModelResourceLocation("controlpanel:redstone_gauge","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.REMOTE,0,new ModelResourceLocation("controlpanel:remote","inventory"));
		ModelLoader.setCustomModelResourceLocation(ModItems.REMOTE,1,new ModelResourceLocation("controlpanel:dark_remote","inventory"));
	}
}