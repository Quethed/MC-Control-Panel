package com.quethed.control_panel;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class ItemRemote extends Item{
	public static int REMOTE_RANGE;
	public static boolean isInRange(BlockPos a,BlockPos b,int range){
		int d=a.getX();
		int c=b.getX();
		if(c>d)d=c-d;
		else d-=c;
		if(d<0)d=-d;
		c=a.getY();
		int g=b.getY();
		if(g>c)c=g-c;
		else c-=g;
		if(c<0)c=-c;
		g=a.getZ();
		int h=b.getZ();
		if(h>g)g=h-g;
		else g-=h;
		if(g<0)g=-g;
		if(g>c)c=g;
		if(c>d)d=c;
		return d<=range;
	}
	public static EnumActionResult triggerRemote(World world,EntityPlayer player,ItemStack remote){
		if(!remote.hasTagCompound())return EnumActionResult.PASS;
		NBTTagCompound t=remote.getTagCompound();
		if(!t.hasKey("RemoteControlData",10))return EnumActionResult.PASS;
		NBTTagCompound d=t.getCompoundTag("RemoteControlData");
		if(!d.hasKey("id",8)||!d.hasKey("x",3)||!d.hasKey("y",3)||!d.hasKey("z",3)){
			d.removeTag("id");
			d.removeTag("x");
			d.removeTag("y");
			d.removeTag("z");
			d.removeTag("CustomName");
			if(d.hasNoTags())t.removeTag("RemoteControlData");
			return EnumActionResult.PASS;
		}
		BlockPos p=new BlockPos(d.getInteger("x"),d.getInteger("y"),d.getInteger("z"));
		BlockPos a=player.getPosition();
		int r=REMOTE_RANGE;
		if(d.hasKey("Range",3))r=d.getInteger("Range");
		if(r>0&&!isInRange(a,p,r)){
			player.sendStatusMessage(new TextComponentTranslation(remote.getItem().getUnlocalizedName()+".outOfRange").setStyle(new Style().setColor(TextFormatting.RED)),true);
			return EnumActionResult.FAIL;
		}
		TileEntity e=world.getTileEntity(p);
		if(e==null||!TileEntity.getKey(e.getClass()).equals(new ResourceLocation(d.getString("id")))){
			d.removeTag("id");
			d.removeTag("x");
			d.removeTag("y");
			d.removeTag("z");
			d.removeTag("CustomName");
			if(d.hasNoTags())t.removeTag("RemoteControlData");
			player.sendStatusMessage(new TextComponentTranslation(remote.getItem().getUnlocalizedName()+".blockNotFound").setStyle(new Style().setColor(TextFormatting.RED)),true);
			return EnumActionResult.FAIL;
		}
		if(e instanceof TileEntityControlPanel){
			if(world.isRemote)net.minecraft.client.Minecraft.getMinecraft().displayGuiScreen(new com.quethed.control_panel.client.GuiControlPanel((TileEntityControlPanel)e,true,r));
			else{
				if(((TileEntityControlPanel)e).hasCustomName())
					d.setString("CustomName",((TileEntityControlPanel)e).getDisplayName().getUnformattedText());
				else d.removeTag("CustomName");
			}
		}
		return EnumActionResult.SUCCESS;
	}
	public ItemRemote(){
		setMaxStackSize(1);
		setMaxDamage(0);
		setHasSubtypes(true);
	}
	@Override@SideOnly(Side.CLIENT)public void addInformation(ItemStack stack,World world,java.util.List<String>tooltip,net.minecraft.client.util.ITooltipFlag flagIn){
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown()){
			String l=net.minecraft.util.text.translation.I18n.translateToLocal(getUnlocalizedName()+".desc");
			String[] s=l.split("\\\\n");
			int i=1;
			for(String t:s){
				tooltip.add(i,t);
				i++;
			}
		}
		else tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocal("moreInfo"));
		int r=48;
		NBTTagCompound n=stack.getSubCompound("RemoteControlData");
		if(n!=null){
			if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown())
				tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted(getUnlocalizedName()+".connected",r));
			if(n.hasKey("Range",3))r=n.getInteger("Range");
		}
		else tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted(getUnlocalizedName()+".notConnected",r));
		if(net.minecraft.client.gui.GuiScreen.isShiftKeyDown())
			tooltip.add(net.minecraft.util.text.translation.I18n.translateToLocalFormatted(getUnlocalizedName()+".range",r));
	}
	@Override public String getItemStackDisplayName(ItemStack stack){
		if(stack.hasTagCompound()){
			NBTTagCompound n=stack.getTagCompound();
			if(n.hasKey("RemoteControlData",10)){
				n=n.getCompoundTag("RemoteControlData");
				if(n.hasKey("CustomName",8))return n.getString("CustomName");
			}
		}
		return super.getItemStackDisplayName(stack);
	}
	@Override public void getSubItems(CreativeTabs tab,NonNullList<ItemStack>items){
		if(!isInCreativeTab(tab))return;
		items.add(new ItemStack(this));
		items.add(new ItemStack(this,1,1));
	}
	@Override public String getUnlocalizedName(ItemStack stack){
		if(stack.getMetadata()>0)return getUnlocalizedName()+".dark";
		return getUnlocalizedName();
	}
	public void linkToTileEntity(ItemStack stack,TileEntityControlPanel te){
		NBTTagCompound n=stack.getOrCreateSubCompound("RemoteControlData");
		n.setString("id",TileEntity.getKey(te.getClass()).toString());
		n.setInteger("x",te.getPos().getX());
		n.setInteger("y",te.getPos().getY());
		n.setInteger("z",te.getPos().getZ());
		if(te.hasCustomName())
			n.setString("CustomName",te.getDisplayName().getUnformattedText());
		else n.removeTag("CustomName");
	}
	@Override public ActionResult<ItemStack>onItemRightClick(World world,EntityPlayer player,EnumHand hand){
		return new ActionResult(triggerRemote(world,player,player.getHeldItem(hand)),player.getHeldItem(hand));
	}
}