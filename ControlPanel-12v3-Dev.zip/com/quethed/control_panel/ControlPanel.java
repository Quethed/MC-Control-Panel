package com.quethed.control_panel;
import com.quethed.control_panel.messages.MessageControlPanel;
import com.quethed.control_panel.messages.MessageControlPanelHandler;
import com.quethed.control_panel.messages.MessageSideChanged;
import com.quethed.control_panel.messages.MessageSideChangedHandler;
import net.minecraft.item.crafting.IRecipe;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.config.Configuration;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
@Mod(modid="controlpanel",name="Control Panel Mod",version="12v2")
@Mod.EventBusSubscriber(modid="controlpanel")
public class ControlPanel{
	@Mod.Instance("controlpanel")public static ControlPanel instance;
	public static final SimpleNetworkWrapper CHANNEL=NetworkRegistry.INSTANCE.newSimpleChannel("controlpanel");
	public static Configuration CONFIG;
	public static Rotation getRotation(EnumFacing rotation){
		return rotation==EnumFacing.EAST?Rotation.COUNTERCLOCKWISE_90:rotation==EnumFacing.NORTH?Rotation.CLOCKWISE_180:rotation==EnumFacing.WEST?Rotation.CLOCKWISE_90:Rotation.NONE;
	}
	@SubscribeEvent public static void registerRecipes(RegistryEvent.Register<IRecipe>event){
		event.getRegistry().registerAll(
			new RecipesTouchscreenDye(ModItems.TOUCHSCREEN_CONTROL_BLOCK,ModItems.DARK_TOUCHSCREEN_CONTROL_BLOCK).setRegistryName("touchscreen_control_block_dyed"),
			new RecipesTouchscreenDye(ModItems.TOUCHSCREEN_CONTROL_PANEL,ModItems.DARK_TOUCHSCREEN_CONTROL_PANEL).setRegistryName("touchscreen_control_panel_dyed")
		);
	}
	public static BlockPos rotate(BlockPos center,int sx,int sz,Rotation rotation){
		if(rotation==Rotation.CLOCKWISE_180)return center.add(-sx,0,-sz);
		if(rotation==Rotation.COUNTERCLOCKWISE_90)return center.add(sz,0,-sx);
		if(rotation==Rotation.CLOCKWISE_90)return center.add(-sz,0,sx);
		return center.add(sx,0,sz);
	}
	public static BlockPos rotate(int y,int sx,int sz,Rotation rotation){
		if(rotation==Rotation.CLOCKWISE_180)return new BlockPos(-sx,y,-sz);
		if(rotation==Rotation.COUNTERCLOCKWISE_90)return new BlockPos(sz,y,-sx);
		if(rotation==Rotation.CLOCKWISE_90)return new BlockPos(-sz,y,sx);
		return new BlockPos(sx,y,sz);
	}
	@Mod.EventHandler public void init(FMLInitializationEvent event)throws Exception{
		ModBlocks.init();
		if(event.getSide()==Side.CLIENT){
			TileEntityControlPanelTouchscreen.DEFAULT_BACKGROUND_COLOR=CONFIG.getInt("default_touchscreen_background_color","client",3715839,0,16777215,"When a touchscreen background is not dyed, what color does it use? The value must be represented by a single integer.");
			TileEntityControlPanelTouchscreen.DEFAULT_FOREGROUND_COLOR=CONFIG.getInt("default_touchscreen_foreground_color","client",16777215,0,16777215,"When a touchscreen foreground is not dyed, what color does it use? The value must be represented by a single integer.");
		}
		ItemRemote.REMOTE_RANGE=CONFIG.getInt("remote_range","main",144,0,Integer.MAX_VALUE,"How far away can a remote control be from its control panel to get a signal? NBT range data is completely uneffected by this option. Set to 0 to disable the system outside of nbt.");
		RecipesTouchscreenDye.CAN_FLIP_FRAME=CONFIG.getBoolean("dye_touchscreen_frames","main",true,"When applying dye to a touchscreen, can you flip between light theme and dark theme frames?");
		CONFIG.save();
		CONFIG=null;
	}
	@Mod.EventHandler public void preInit(FMLPreInitializationEvent event){
		CONFIG=new Configuration(event.getSuggestedConfigurationFile());
		GameRegistry.registerTileEntity(TileEntityControlPanel.class,"controlpanel:control_panel");
		GameRegistry.registerTileEntity(TileEntityControlPanelTouchscreen.class,"controlpanel:touchscreen_control_panel");
		GameRegistry.registerTileEntity(TileEntityMotherboard.class,"controlpanel:motherboard");
		GameRegistry.registerTileEntity(TileEntityGauge.class,"controlpanel:redstone_gauge");
		CHANNEL.registerMessage(MessageControlPanelHandler.class,MessageControlPanel.class,0,Side.SERVER);
		CHANNEL.registerMessage(MessageSideChangedHandler.class,MessageSideChanged.class,1,Side.CLIENT);
		if(event.getSide()==Side.CLIENT)
			MinecraftForge.EVENT_BUS.register(new com.quethed.control_panel.client.ControlPanelClient());
		MinecraftForge.EVENT_BUS.register(new ModBlocks());
		MinecraftForge.EVENT_BUS.register(new ModItems());
	}
}
