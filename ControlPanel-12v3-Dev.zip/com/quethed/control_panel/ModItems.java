package com.quethed.control_panel;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
public class ModItems{
	@GameRegistry.ObjectHolder("controlpanel:control_block")public static final ItemBlock CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:control_panel")public static final ItemBlock CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_control_block")public static final ItemBlock DARK_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_control_panel")public static final ItemBlock DARK_CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_touchscreen_control_block")public static final ItemBlock DARK_TOUCHSCREEN_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:dark_touchscreen_control_panel")public static final ItemBlock DARK_TOUCHSCREEN_CONTROL_PANEL=null;
	@GameRegistry.ObjectHolder("controlpanel:motherboard")public static final ItemBlockLinkable MOTHERBOARD=null;
	@GameRegistry.ObjectHolder("controlpanel:redstone_gauge")public static final ItemBlockLinkable REDSTONE_GAUGE=null;
	@GameRegistry.ObjectHolder("controlpanel:remote")public static final ItemRemote REMOTE=null;
	@GameRegistry.ObjectHolder("controlpanel:touchscreen_control_block")public static final ItemBlock TOUCHSCREEN_CONTROL_BLOCK=null;
	@GameRegistry.ObjectHolder("controlpanel:touchscreen_control_panel")public static final ItemBlock TOUCHSCREEN_CONTROL_PANEL=null;
	@SubscribeEvent void registerItems(RegistryEvent.Register<Item>event){
		event.getRegistry().registerAll(
			new ItemBlock(ModBlocks.CONTROL_BLOCK).setRegistryName("control_block"),
			new ItemBlock(ModBlocks.CONTROL_PANEL).setRegistryName("control_panel"),
			new ItemBlock(ModBlocks.DARK_CONTROL_BLOCK).setRegistryName("dark_control_block"),
			new ItemBlock(ModBlocks.DARK_CONTROL_PANEL).setRegistryName("dark_control_panel"),
			new ItemBlock(ModBlocks.DARK_TOUCHSCREEN_CONTROL_BLOCK).setRegistryName("dark_touchscreen_control_block"),
			new ItemBlock(ModBlocks.DARK_TOUCHSCREEN_CONTROL_PANEL).setRegistryName("dark_touchscreen_control_panel"),
			new ItemBlockLinkable(ModBlocks.MOTHERBOARD).setRegistryName("motherboard"),
			new ItemBlockLinkable(ModBlocks.REDSTONE_GAUGE).setRegistryName("redstone_gauge"),
			new ItemBlock(ModBlocks.TOUCHSCREEN_CONTROL_BLOCK).setRegistryName("touchscreen_control_block"),
			new ItemBlock(ModBlocks.TOUCHSCREEN_CONTROL_PANEL).setRegistryName("touchscreen_control_panel"),
			new ItemRemote().setRegistryName("remote").setUnlocalizedName("remote").setCreativeTab(CreativeTabs.REDSTONE)
		);
	}
}