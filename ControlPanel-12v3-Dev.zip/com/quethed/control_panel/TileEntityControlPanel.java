package com.quethed.control_panel;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import com.quethed.control_panel.blocks.BlockControl;
import com.quethed.control_panel.messages.MessageSideChanged;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemNameTag;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagByte;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.nbt.NBTTagString;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.IWorldNameable;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
public class TileEntityControlPanel extends TileEntity implements ITickable,IWorldNameable{
	protected final ArrayList<BlockPos>links=new ArrayList();
	protected String name;
	protected final ControlPanelSideInfo[]sides=new ControlPanelSideInfo[6];
	public boolean ticks;
	public void addLink(BlockPos link){
		EnumFacing f=world.getBlockState(pos).getValue(BlockControl.FACING);
		if(f==EnumFacing.EAST)f=EnumFacing.WEST;
		else if(f==EnumFacing.WEST)f=EnumFacing.EAST;
		links.add(ControlPanel.rotate(-link.getY(),-link.getX(),-link.getZ(),ControlPanel.getRotation(f)));
	}
	public List<BlockPos>getAndConfirmLinks(){
		for(int i=0;i<links.size();i++){
			BlockPos l=links.get(i);
			l=ControlPanel.rotate(pos.up(l.getY()),l.getX(),l.getZ(),ControlPanel.getRotation(world.getBlockState(pos).getValue(BlockControl.FACING)));
			TileEntity t=world.getTileEntity(l);
			if(t==null){
				links.remove(i);
				i--;
				markDirty();
				world.notifyNeighborsOfStateChange(pos,blockType,true);
			}
		}
		return links;
	}
	@Override@Nullable public ITextComponent getDisplayName(){
		return name==null?new TextComponentTranslation("container.control_panel"):new TextComponentString(name);
	}
	public ItemStack getItemDropped(BlockControl block){return new ItemStack(block);}
	public int getLinkCount(){return links.size();}
	@Override public String getName(){return name==null?"container.control_panel":name;}
	@Nullable public ControlPanelSideInfo getSide(EnumFacing side){return sides[getRotation(side).getIndex()];}
	@Nullable public ControlPanelSideInfo getSide(int side){return sides[side];}
	public EnumFacing getRotation(EnumFacing side){
		if(side==EnumFacing.UP||side==EnumFacing.DOWN)return side;
		IBlockState b=world.getBlockState(pos);
		if(b.getBlock() instanceof BlockControl){
			EnumFacing f=b.getValue(BlockControl.FACING);
			if(f==EnumFacing.WEST)return side.rotateYCCW();
			if(f==EnumFacing.NORTH)return side.getOpposite();
			if(f==EnumFacing.EAST)return side.rotateY();
		}
		return side;
	}
	@Override public NBTTagCompound getUpdateTag(){return writeToNBT(new NBTTagCompound());}
	@Override public boolean hasCustomName(){return name!=null;}
	@SideOnly(Side.CLIENT)public void messageRecieved(byte change,@Nullable String name){
		if(change<6){
			sides[change]=null;
			return;
		}
		byte s=(byte)(change%6);
		ControlPanelSideInfo a=sides[s];
		if(a==null){
			a=new ControlPanelSideInfo();
			sides[s]=a;
		}
		if(change<18){
			a.name=name;
			a.leverMode=change<12;
			return;
		}
		else a.powered=change<24;
	}
	@Override public void onDataPacket(NetworkManager net,SPacketUpdateTileEntity pkt){handleUpdateTag(pkt.getNbtCompound());}
	@Override public void readFromNBT(NBTTagCompound compound){
		ticks=false;
		NBTTagList l=compound.getTagList("SwitchStates",1);
		for(int i=0;i<l.tagCount();i++){
			byte s=((NBTTagByte)l.get(i)).getByte();
			if(s<4){
				ControlPanelSideInfo a=new ControlPanelSideInfo();
				a.leverMode=s/2==1;
				if(!a.leverMode)ticks=true;
				a.powered=s%2==1;
				sides[i]=a;
			}
			else sides[i]=null;
		}
		l=compound.getTagList("SwitchNames",8);
		for(int i=0;i<l.tagCount();i++)
			if(sides[i]!=null)sides[i].name=l.getStringTagAt(i);
		links.clear();
		l=compound.getTagList("Links",10);
		for(NBTBase i:l){
			NBTTagCompound a=(NBTTagCompound)i;
			if(a.hasKey("x",3)&&a.hasKey("y",3)&&a.hasKey("z",3))
				links.add(new BlockPos(a.getInteger("x"),a.getInteger("y"),a.getInteger("z")));
		}
		if(compound.hasKey("CustomName",8))name=compound.getString("CustomName");
		super.readFromNBT(compound);
		refresh(world);
	}
	public void refresh(World world){
		if(world==null)return;
		markDirty();
		world.notifyNeighborsOfStateChange(pos,blockType,true);
		for(int i=0;i<links.size();i++){
			BlockPos l=ControlPanel.rotate(pos.up(links.get(i).getY()),links.get(i).getX(),links.get(i).getZ(),ControlPanel.getRotation(world.getBlockState(pos).getValue(BlockControl.FACING)));
			TileEntity t=world.getTileEntity(l);
			if(t!=null){
				t.markDirty();
				world.notifyNeighborsOfStateChange(l,t.getBlockType(),true);
			}
			else{
				links.remove(i);
				i--;
				markDirty();
				world.notifyNeighborsOfStateChange(pos,blockType,true);
			}
		}
	}
	public boolean replaceSide(World world,ItemStack stack,EnumFacing side,boolean shrink,EntityLivingBase entity){
		if(stack.getItem()==BlockControl.BUTTON&&getSide(side)==null){
			ControlPanelSideInfo i=new ControlPanelSideInfo();
			i.leverMode=false;
			if(stack.hasDisplayName())i.name=stack.getDisplayName();
			setSide(side,i);
			ticks=true;
			if(shrink)stack.shrink(1);
			refresh(world);
			return true;
		}
		if(stack.getItem()==BlockControl.LEVER&&getSide(side)==null){
			ControlPanelSideInfo i=new ControlPanelSideInfo();
			if(stack.hasDisplayName())i.name=stack.getDisplayName();
			setSide(side,i);
			ticks=false;
			for(ControlPanelSideInfo a:sides)if(a!=null&&!a.leverMode)ticks=true;
			if(shrink)stack.shrink(1);
			refresh(world);
			return true;
		}
		if(BlockControl.EXTRACT.contains(stack.getItem())){
			ControlPanelSideInfo i=getSide(side);
			if(i==null)return false;
			if(!world.isRemote){
				ItemStack s=new ItemStack(i.leverMode?BlockControl.LEVER:BlockControl.BUTTON);
				if(!i.name.matches(""))s.setStackDisplayName(i.name);
				BlockPos p=pos.offset(side.getOpposite());
				EntityItem e=new EntityItem(world,p.getX(),p.getY(),p.getZ());
				e.setItem(s);
				world.spawnEntity(e);
				if(shrink&&stack.isItemStackDamageable())
					stack.damageItem(1,entity);
			}
			setSide(side,null);
			ticks=false;
			for(ControlPanelSideInfo a:sides)if(a!=null&&!a.leverMode)ticks=true;
			refresh(world);
			return true;
		}
		if(stack.getItem()instanceof ItemNameTag){
			ControlPanelSideInfo i=getSide(side);
			if(i!=null&&stack.hasDisplayName()){
				i.name=stack.getDisplayName();
				refresh(world);
				return true;
			}
		}
		return false;
	}
	public void setCustomName(String name){this.name=name;}
	public void setSide(EnumFacing side,ControlPanelSideInfo value){
		byte c=(byte)getRotation(side).getIndex();
		sides[c]=value;
		String n;
		if(value==null)n=null;
		else{
			if(value.leverMode)c+=6;
			else c+=12;
			n=value.name;
		}
		if(!world.isRemote)ControlPanel.CHANNEL.sendToDimension(new MessageSideChanged(pos.getX(),pos.getY(),pos.getZ(),c,n),world.provider.getDimension());
	}
	@Override public void update(){
		if(!ticks)return;
		for(int i=0;i<6;i++){
			ControlPanelSideInfo s=sides[i];
			if(s==null||s.leverMode||s.poweredTime<1)continue;
			s.poweredTime--;
			if(s.poweredTime>0)continue;
			s.powered=false;
			if(!world.isRemote)ControlPanel.CHANNEL.sendToDimension(new MessageSideChanged(pos.getX(),pos.getY(),pos.getZ(),(byte)(i+24),null),world.provider.getDimension());
			refresh(world);
		}
	}
	public void useSide(EnumFacing side){
		byte c=(byte)getRotation(side).getIndex();
		ControlPanelSideInfo i=sides[c];
		if(i==null)return;
		if(i.leverMode)i.powered=!i.powered;
		else if(!i.powered){
			i.powered=true;
			i.poweredTime=20;
		}
		if(!world.isRemote){
			if(i.powered)c+=18;
			else c+=24;
			ControlPanel.CHANNEL.sendToDimension(new MessageSideChanged(pos.getX(),pos.getY(),pos.getZ(),c,null),world.provider.getDimension());
		}
		refresh(getWorld());
	}
	public void writeName(NBTTagCompound compound){
		if(name!=null)compound.setString("CustomName",name);
	}
	public void writeSides(NBTTagCompound compound){
		NBTTagList l=new NBTTagList();
		for(ControlPanelSideInfo i:sides){
			if(i==null)l.appendTag(new NBTTagByte((byte)4));
			else l.appendTag(new NBTTagByte((byte)(i.leverMode?(i.powered?3:2):i.powered?1:0)));
		}
		compound.setTag("SwitchStates",l);
		l=new NBTTagList();
		for(ControlPanelSideInfo i:sides){
			if(i==null)l.appendTag(new NBTTagString(""));
			else l.appendTag(new NBTTagString(i.name));
		}
		compound.setTag("SwitchNames",l);
	}
	@Override public NBTTagCompound writeToNBT(NBTTagCompound compound){
		writeSides(compound);
		NBTTagList l=new NBTTagList();
		for(BlockPos i:links){
			NBTTagCompound a=new NBTTagCompound();
			a.setInteger("x",i.getX());
			a.setInteger("y",i.getY());
			a.setInteger("z",i.getZ());
			l.appendTag(a);
		}
		if(!l.hasNoTags())compound.setTag("Links",l);
		writeName(compound);
		return super.writeToNBT(compound);
	}
}