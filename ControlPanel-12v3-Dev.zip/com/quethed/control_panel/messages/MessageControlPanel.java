package com.quethed.control_panel.messages;
import io.netty.buffer.ByteBuf;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
public class MessageControlPanel implements IMessage{
	EnumFacing side;
	int x,y,z;
	public MessageControlPanel(int x,int y,int z,EnumFacing side){
		this.side=side;
		this.x=x;
		this.y=y;
		this.z=z;
	}
	public MessageControlPanel(){}
	@Override public void fromBytes(ByteBuf buf){
		x=buf.readInt();
		y=buf.readInt();
		z=buf.readInt();
		side=EnumFacing.VALUES[buf.readByte()];
	}
	@Override public void toBytes(ByteBuf buf){
		buf.writeInt(x);
		buf.writeInt(y);
		buf.writeInt(z);
		buf.writeByte(side.getIndex());
	}
}