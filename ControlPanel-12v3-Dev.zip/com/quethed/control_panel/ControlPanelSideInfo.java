package com.quethed.control_panel;
public class ControlPanelSideInfo{
	public boolean leverMode=true;
	public String name="";
	public boolean powered;
	public int poweredTime;
}