package com.quethed.control_panel;
import java.util.List;
import com.quethed.control_panel.blocks.BlockControl;
import com.quethed.control_panel.blocks.BlockGauge;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
public class ControlPanelServer{
	public static void breakControlBlock(BlockControl block,World world,BlockPos pos,IBlockState state){
		List<ItemStack>c=block.getDrops(world,pos,state,0);
		for(ItemStack a:c){
			EntityItem b=new EntityItem(world,pos.getX()+world.rand.nextDouble(),pos.getY()+world.rand.nextDouble(),pos.getZ()+world.rand.nextDouble());
			b.setItem(a);
			world.spawnEntity(b);
		}
	}
	public static void neighborChangedGauge(BlockGauge gauge,IBlockState state,World world,BlockPos pos,Block block,BlockPos fromPos){
		if(!world.isBlockTickPending(pos,gauge)){
			TileEntity b=world.getTileEntity(pos);
			if(b instanceof TileEntityGauge&&((TileEntityGauge)b).getLink()!=null)return;
			int i=gauge.calculateInputStrength(world,pos,state);
			TileEntity t=world.getTileEntity(pos);
			int j=t instanceof TileEntityGauge?((TileEntityGauge)t).getOutputSignal():0;
			if(i!=j)world.updateBlockTick(pos,gauge,2,0);
		}
	}
}